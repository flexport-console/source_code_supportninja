<div class="footer">
    <div class="copyright">
        <p>Copyright © Developed by <a href="http://facebook.com/iamjerz" target="_blank">Jerramy Calites</a> 2023</p>
    </div>
</div>