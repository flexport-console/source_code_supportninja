(function($) {
    "use strict"

    $("#tags_1").tagsinput();

})(jQuery);